var searchData=
[
  ['getname_0',['getName',['../classPlayer.html#a4939193fc637f75bf7a11118334dae7e',1,'Player']]],
  ['getroll_1',['getRoll',['../classPlayer.html#a49e166d8ce431ddc130a44184ba3f6ca',1,'Player']]]
];
