var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classPlayer.html#a24fe0eb7b3d2fe988df201c5974b6382',1,'Player']]]
];
