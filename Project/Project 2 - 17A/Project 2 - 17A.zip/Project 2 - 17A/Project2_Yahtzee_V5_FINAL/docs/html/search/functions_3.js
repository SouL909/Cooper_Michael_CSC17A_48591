var searchData=
[
  ['play_0',['play',['../classYahtzee.html#ac1f7a7feae528f92356fa9b97c231e21',1,'Yahtzee']]],
  ['player_1',['Player',['../classPlayer.html#affe0cc3cb714f6deb4e62f0c0d3f1fd8',1,'Player::Player()'],['../classPlayer.html#af5aaea393030f959d568c806ca9100ca',1,'Player::Player(std::string name)'],['../classPlayer.html#ac75e0d687515a5b5f2643620abe4d19c',1,'Player::Player(Player &amp;player)']]]
];
