var searchData=
[
  ['setname_0',['setName',['../classPlayer.html#a95d2b46eee230ad3e31612ff2bc681da',1,'Player']]],
  ['setroll_1',['setRoll',['../classPlayer.html#a94d140c1cea66ed7cd6898ec9738cbf8',1,'Player']]],
  ['strmlst_2',['strmlst',['../player_8h.html#a115d61e7a628ec1e63d29a558e5ed502',1,'player.h']]]
];
