/*
 * File:   main.cpp
 * Author: michaelcooper
 * Created on December 5, 2021, 10:07 PM
 * Project 2: Yahtzee V1
 * Making basic outline for project and identifying new changes
 */

#include <cstdlib>
#include "Yahtzee.h"
using namespace std;

//I want to make the main as short as possible to fully utilize the other sections 
//and apply as many requirements. Included the main turn functions of the game to start with
//still need to tweak and include other files, so this version does not run.

int main(int, char**) {
    Yahtzee yhtz;
    yhtz.play();
    return 0;
}

